# Push real sin Firebase Blaze

Este Worker es el servidor externo que envía FCM HTTP v1 sin usar Firebase Cloud Functions.

1. Crear un Worker gratuito en Cloudflare.
2. Desplegar este directorio.
3. Crear el secreto `FIREBASE_SERVICE_ACCOUNT_JSON` con el JSON de una cuenta de servicio de Firebase Admin SDK.
4. Copiar la URL `https://...workers.dev` en `PUSH_WORKER_URL` de `MainActivity.kt`.
5. Compilar la APK.

El mensaje sigue guardándose exactamente en `privateMessages`; el Worker solo añade el envío push después de que Firestore confirma el mensaje.
