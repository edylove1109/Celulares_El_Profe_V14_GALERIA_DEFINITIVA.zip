import { importPKCS8, SignJWT, jwtVerify, createRemoteJWKSet } from 'jose';

const GOOGLE_TOKEN_URL = 'https://oauth2.googleapis.com/token';
const FCM_SCOPE = 'https://www.googleapis.com/auth/firebase.messaging';
const GOOGLE_CERTS = createRemoteJWKSet(new URL('https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com'));

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json' } });
}

function base64url(input) {
  return btoa(input).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

async function serviceAccountAccessToken(env) {
  const sa = JSON.parse(env.FIREBASE_SERVICE_ACCOUNT_JSON);
  const key = await importPKCS8(sa.private_key, 'RS256');
  const now = Math.floor(Date.now() / 1000);
  const assertion = await new SignJWT({ scope: FCM_SCOPE })
    .setProtectedHeader({ alg: 'RS256', typ: 'JWT' })
    .setIssuer(sa.client_email)
    .setAudience(GOOGLE_TOKEN_URL)
    .setIssuedAt(now)
    .setExpirationTime(now + 3600)
    .sign(key);
  const body = new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion });
  const r = await fetch(GOOGLE_TOKEN_URL, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body });
  if (!r.ok) throw new Error(`OAuth ${r.status}: ${await r.text()}`);
  return (await r.json()).access_token;
}

async function verifyFirebaseIdToken(token, projectId) {
  const { payload } = await jwtVerify(token, GOOGLE_CERTS, {
    issuer: `https://securetoken.google.com/${projectId}`,
    audience: projectId
  });
  if (!payload.sub) throw new Error('Token Firebase sin uid');
  return String(payload.sub);
}

async function firestoreGetUser(env, accessToken, uid) {
  const url = `https://firestore.googleapis.com/v1/projects/${encodeURIComponent(env.FIREBASE_PROJECT_ID)}/databases/(default)/documents/users/${encodeURIComponent(uid)}`;
  const r = await fetch(url, { headers: { authorization: `Bearer ${accessToken}` } });
  if (r.status === 404) return null;
  if (!r.ok) throw new Error(`Firestore ${r.status}: ${await r.text()}`);
  const d = await r.json();
  const fields = d.fields || {};
  return fields.fcmToken?.stringValue || null;
}

async function sendFcm(env, accessToken, token, title, body, messageId) {
  const url = `https://fcm.googleapis.com/v1/projects/${encodeURIComponent(env.FIREBASE_PROJECT_ID)}/messages:send`;
  const payload = { message: {
    token,
    notification: { title, body },
    data: { type: 'private_message', messageId: messageId || '' },
    android: { priority: 'HIGH', notification: { channelId: 'celulares_el_profe_mensajes', sound: 'default' } }
  }};
  const r = await fetch(url, { method: 'POST', headers: { authorization: `Bearer ${accessToken}`, 'content-type': 'application/json' }, body: JSON.stringify(payload) });
  const text = await r.text();
  if (!r.ok) throw new Error(`FCM ${r.status}: ${text}`);
  return text;
}

export default {
  async fetch(request, env) {
    if (request.method !== 'POST') return json({ ok: false, error: 'POST requerido' }, 405);
    try {
      const auth = request.headers.get('authorization') || '';
      if (!auth.startsWith('Bearer ')) return json({ ok: false, error: 'Falta token Firebase' }, 401);
      const callerUid = await verifyFirebaseIdToken(auth.slice(7), env.FIREBASE_PROJECT_ID);
      const input = await request.json();
      const recipientUid = String(input.recipientUid || '').trim();
      const title = String(input.title || 'Celulares El Profe').slice(0, 80);
      const body = String(input.body || '').trim().slice(0, 300);
      const messageId = String(input.messageId || '').trim();
      if (!recipientUid || !body) return json({ ok: false, error: 'Datos incompletos' }, 400);
      const accessToken = await serviceAccountAccessToken(env);
      const targetUid = recipientUid === 'ADMIN' ? await findAdminUid(env, accessToken) : recipientUid;
      if (!targetUid) return json({ ok: false, error: 'No hay administrador con token FCM' }, 404);
      const fcmToken = await firestoreGetUser(env, accessToken, targetUid);
      if (!fcmToken) return json({ ok: false, error: 'El destinatario no tiene token FCM' }, 404);
      await sendFcm(env, accessToken, fcmToken, title, body, messageId);
      return json({ ok: true, senderUid: callerUid });
    } catch (e) {
      return json({ ok: false, error: String(e?.message || e) }, 500);
    }
  }
};

async function findAdminUid(env, accessToken) {
  const q = `https://firestore.googleapis.com/v1/projects/${encodeURIComponent(env.FIREBASE_PROJECT_ID)}/databases/(default)/documents:runQuery`;
  const r = await fetch(q, { method: 'POST', headers: { authorization: `Bearer ${accessToken}`, 'content-type': 'application/json' }, body: JSON.stringify({ structuredQuery: { from: [{ collectionId: 'users' }], where: { fieldFilter: { field: { fieldPath: 'role' }, op: 'EQUAL', value: { stringValue: 'admin' } } }, limit: 1 } }) });
  if (!r.ok) throw new Error(`Firestore query ${r.status}: ${await r.text()}`);
  const rows = await r.json();
  return rows[0]?.document?.name?.split('/').pop() || null;
}
