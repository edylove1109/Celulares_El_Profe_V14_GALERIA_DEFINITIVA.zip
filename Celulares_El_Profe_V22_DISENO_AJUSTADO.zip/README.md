# Celulares El Profe — V22 PUSH

Esta V22 parte de la V21 estable y modifica únicamente el flujo de **notificación push**.

- Conserva Firestore `privateMessages` y el flujo existente de mensajes.
- La APK intenta avisar al Worker después de confirmar que el mensaje se guardó.
- El Worker usa FCM HTTP v1 sin Firebase Cloud Functions/Blaze.
- El proyecto incluye un workflow de GitHub Actions que puede construir la APK incluso si el repositorio contiene este ZIP en la raíz.

## Importante

La constante `PUSH_WORKER_URL` queda vacía hasta desplegar el Worker. Sin esa URL, los mensajes siguen funcionando pero no habrá envío push externo.

El Worker requiere el secreto `FIREBASE_SERVICE_ACCOUNT_JSON`. Esa credencial **no debe ponerse dentro de la APK**.
