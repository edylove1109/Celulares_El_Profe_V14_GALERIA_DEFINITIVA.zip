const { onDocumentCreated } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");
const logger = require("firebase-functions/logger");

initializeApp();

const db = getFirestore();

async function sendToUser(uid, title, body, messageId) {
  const userSnap = await db.collection("users").doc(uid).get();
  const token = userSnap.get("fcmToken");
  if (!token) return;

  try {
    await getMessaging().send({
      token,
      notification: { title, body },
      data: {
        type: "private_message",
        messageId: messageId || ""
      },
      android: {
        priority: "high",
        notification: {
          channelId: "celulares_el_profe_mensajes",
          sound: "default"
        }
      }
    });
  } catch (error) {
    logger.warn("No se pudo enviar la notificación al usuario", {
      uid,
      error: error.message
    });
    if (error.code === "messaging/registration-token-not-registered" ||
        error.code === "messaging/invalid-registration-token") {
      await db.collection("users").doc(uid).set({ fcmToken: null }, { merge: true });
    }
  }
}

exports.notifyPrivateMessage = onDocumentCreated("privateMessages/{messageId}", async (event) => {
  const snapshot = event.data;
  if (!snapshot) return;

  const message = snapshot.data() || {};
  const senderUid = String(message.senderUid || "");
  const recipientUid = String(message.recipientUid || "");
  const text = String(message.text || "").trim();
  if (!senderUid || !recipientUid || !text) return;

  const senderName = String(message.senderEmail || "Cliente");
  const preview = text.length > 120 ? `${text.slice(0, 117)}...` : text;

  if (recipientUid === "ADMIN") {
    const admins = await db.collection("users").where("role", "==", "admin").get();
    await Promise.all(admins.docs.map((doc) =>
      sendToUser(doc.id, "💬 Nuevo mensaje", `${senderName}: ${preview}`, event.params.messageId)
    ));
    return;
  }

  // Messages addressed to a real administrator UID are handled exactly like
  // messages addressed to any other user. This is the preferred V17 path.
  const recipientSnap = await db.collection("users").doc(recipientUid).get();
  const recipientRole = recipientSnap.exists ? String(recipientSnap.get("role") || "") : "";
  await sendToUser(recipientUid, recipientRole === "admin" ? "💬 Nuevo mensaje" : "💬 Celulares El Profe",
    recipientRole === "admin" ? `${senderName}: ${preview}` : preview, event.params.messageId);
});
