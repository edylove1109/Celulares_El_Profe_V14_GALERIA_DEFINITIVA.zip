# Celulares El Profe — V5
Versión 1.4 (versionCode 5).

Cambios:
- Nuevo icono de launcher basado en el logo azul proporcionado.
- Logo visible también en la cabecera de la app.
- Panel de administrador ampliado: Resumen, Productos, Cuentas, Mensajes, Avisos, Diseño y Configuración.
- Diseño configurable desde el administrador: título, subtítulo, colores, fondo, tarjetas y video de introducción.
- Imagen de cabecera seleccionable desde la galería y comprimida para guardarse en Firestore.
- Configuración visual global guardada en appSettings/main.
- El panel admin NO usa contraseña/PIN adicional: requiere que el usuario autenticado tenga role=admin en users/{uid}.
- Cuentas de clientes y mensajes privados conectados a Firebase.
- versionCode 5 / versionName 1.4.

IMPORTANTE:
1. Publica firestore/firestore.rules en Firebase.
2. El usuario administrador debe tener role = admin en users/{uid}.
3. Genera el APK desde GitHub Actions.
4. Para probar el icono nuevo, desinstala la versión anterior antes de instalar el APK nuevo.
5. La cuenta de saldo no crea por sí sola una cuenta de acceso de Firebase; el cliente debe registrarse con el mismo correo.
